import subprocess

def test_cli():
	result = subprocess.run(
		["docsearchdemo", "tests/test_data", "Alice"],
		capture_output=True,
		text=True
	)

	assert result.returncode == 1
	assert "Alice" in result.stdout